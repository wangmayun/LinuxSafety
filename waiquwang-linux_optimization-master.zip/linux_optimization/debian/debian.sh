#!/bin/bash
### Hardening Script for Debian10 Servers.
AUDITDIR="/tmp/$(hostname -s)_audit"
TIME="$(date +%F_%T)"

mkdir -p $AUDITDIR

echo "Disabling Legacy Filesystems"
cat > /etc/modprobe.d/jffs2.conf << "EOF